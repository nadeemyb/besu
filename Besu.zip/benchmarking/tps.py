import pandas as pd
import matplotlib.pyplot as plt

# Dataset with updated labels and TPS values
data = {
    "Consensus": ["QBFT", "QBFT", "QBFT", "QBFT",
                  "IBFT2", "IBFT2", "IBFT2", "IBFT2",
                  "Clique", "Clique", "Clique", "Clique"],
    "Tx #": ["1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)",
             "1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)",
             "1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)"],
    "TPS": [0.167, 0.167, 0.167, 0.20,     # QBFT
            0.081, 0.079, 0.082, 0.11,     # IBFT2
            0.107, 0.107, 0.107, 0.11]     # Clique
}

df = pd.DataFrame(data)

# Plot
fig, ax = plt.subplots(figsize=(12, 6))

# Grouped bar plot: x = Tx #, groups = Consensus
width = 0.25
tx_labels = ["1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)"]
x = range(len(tx_labels))

for i, consensus in enumerate(df["Consensus"].unique()):
    subset = df[df["Consensus"] == consensus]
    ax.bar([p + i*width for p in x],
           subset["TPS"],
           width=width, label=consensus)

# Formatting
ax.set_xticks([p + width for p in x])
ax.set_xticklabels(tx_labels)
ax.set_xlabel("Transaction Type")
ax.set_ylabel("Transactions Per Second (TPS)")
ax.set_title("TPS by Consensus Mechanism and Transaction Type")
ax.legend()

plt.tight_layout()
plt.show()
