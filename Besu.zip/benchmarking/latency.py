import pandas as pd
import matplotlib.pyplot as plt

# Dataset
data = {
    "Consensus": ["QBFT", "QBFT", "QBFT", "QBFT",
                  "IBFT2", "IBFT2", "IBFT2", "IBFT2",
                  "Clique", "Clique", "Clique", "Clique"],
    "Tx #": ["1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)",
             "1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)",
             "1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)"],
    "Avg Latency (s)": [4.90, 5.10, 4.90, 3.884,   # QBFT
                        12.053, 12.087, 11.958, 10.166,  # IBFT2
                        8.318, 8.319, 8.303, 7.780]      # Clique
}

df = pd.DataFrame(data)

# Plot
fig, ax = plt.subplots(figsize=(10, 6))

# Transaction labels
tx_labels = ["1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)"]
x = range(len(tx_labels))

# Plot each consensus mechanism as a line
for consensus in df["Consensus"].unique():
    subset = df[df["Consensus"] == consensus]
    ax.plot(x,
            subset["Avg Latency (s)"],
            marker='o',
            linewidth=2,
            label=consensus)

# Formatting
ax.set_xticks(x)
ax.set_xticklabels(tx_labels, rotation=15)
ax.set_xlabel("Transaction Type", fontsize=12)
ax.set_ylabel("Average Latency (s)", fontsize=12)
ax.set_title("Average Latency by Consensus Mechanism and Transaction Type", fontsize=14)
ax.grid(True, linestyle='--', alpha=0.6)
ax.legend(title="Consensus", fontsize=11)

plt.tight_layout()
plt.show()
