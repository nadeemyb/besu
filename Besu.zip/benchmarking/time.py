import pandas as pd
import matplotlib.pyplot as plt

# Dataset with updated labels and Response Time values
data = {
    "Consensus": ["QBFT", "QBFT", "QBFT", "QBFT",
                  "IBFT2", "IBFT2", "IBFT2", "IBFT2",
                  "Clique", "Clique", "Clique", "Clique"],
    "Tx #": ["1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)",
             "1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)",
             "1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)"],
    "Response Time (s)": [18.03, 18.02, 17.97, 25.46,   # QBFT
                          39.17, 38.98, 38.88, 45.12,   # IBFT2
                          28.00, 28.00, 27.97, 44.99]   # Clique
}

df = pd.DataFrame(data)

# Plot
fig, ax = plt.subplots(figsize=(12, 6))

# Grouped bar plot: x = Tx #, groups = Consensus
width = 0.25
tx_labels = ["1 (True, Full)", "2 (True, Partial)", "3 (False, None)", "4 (False, Full)"]
x = range(len(tx_labels))

for i, consensus in enumerate(df["Consensus"].unique()):
    subset = df[df["Consensus"] == consensus]
    ax.bar([p + i*width for p in x],
           subset["Response Time (s)"],
           width=width, label=consensus)

# Formatting
ax.set_xticks([p + width for p in x])
ax.set_xticklabels(tx_labels)
ax.set_xlabel("Transaction Type")
ax.set_ylabel("Response Time (s)")
ax.set_title("Response Time by Consensus Mechanism and Transaction Type")
ax.legend()

plt.tight_layout()
plt.show()
