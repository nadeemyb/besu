import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Dataset
data = {
    "Consensus": ["QBFT", "QBFT", "QBFT", "QBFT",
                  "IBFT2", "IBFT2", "IBFT2", "IBFT2",
                  "Clique", "Clique", "Clique", "Clique"],
    "Tx #": [1, 2, 3, 4,
             1, 2, 3, 4,
             1, 2, 3, 4],
    "CPU Usage": [2.3, 1.9, 1.8, 2.5,
                  4.7, 4.7, 4.7, 4.4,
                  5.4, 4.9, 4.8, 4.9],
    "Memory Usage": [5146.3, 5144.2, 5138.7, 5420.9,
                     5017.5, 5020.6, 5020.8, 5427.6,
                     6042.5, 5689.2, 5532.2, 5872.3],
    "Gas Usage": [413351, 413475, 393783, 101218,
                  410740, 407964, 390454, 101218,
                  128558, 125842, 198211, 189212]
}

df = pd.DataFrame(data)

# Plot setup
fig, axes = plt.subplots(3, 1, figsize=(12, 14), sharex=True)

metrics = ["CPU Usage", "Memory Usage", "Gas Usage"]
consensus_list = df["Consensus"].unique()
colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]  # QBFT, IBFT2, Clique

x = np.arange(len(df["Tx #"].unique()))  # transaction numbers
bar_width = 0.25

for ax, metric in zip(axes, metrics):
    for i, consensus in enumerate(consensus_list):
        subset = df[df["Consensus"] == consensus]
        ax.bar(
            x + i * bar_width,
            subset[metric],
            width=bar_width,
            label=consensus if metric == "CPU Usage" else "",  # legend only once
            color=colors[i]
        )

    ax.set_ylabel(metric)
    ax.set_title(f"{metric} by Consensus Mechanism")
    ax.grid(axis="y", linestyle="--", alpha=0.6)

# X-axis ticks with custom labels
custom_labels = ["1 (True, Full)",
                 "2 (True, Partial)",
                 "3 (False, None)",
                 "4 (False, Full)"]

axes[-1].set_xticks(x + bar_width)  # center under grouped bars
axes[-1].set_xticklabels(custom_labels, rotation=20)
axes[-1].set_xlabel("Transaction #")

# Legend only once (CPU plot)
axes[0].legend()

plt.tight_layout()
plt.show()
