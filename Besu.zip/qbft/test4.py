import json
import time
import random
import psutil
from statistics import mean
from web3 import Web3

# Initialize Web3 connection
w3 = Web3(Web3.HTTPProvider("http://localhost:8545"))
if not w3.is_connected():
    print("❌ Failed to connect to Ethereum node")
    exit()

# Load contract ABI
try:
    with open("PBACSystem_abi.json") as f:
        contract_abi = json.load(f)
except Exception as e:
    print(f"❌ Failed to load ABI: {e}")
    exit()

# Contract setup
contract_address = "0x9e8725C529DAC7ebEFf6F82Eff9c7ab1E2283E0d"
contract = w3.eth.contract(address=contract_address, abi=contract_abi)

# Accounts configuration - FIXED CONTROLLER ADDRESS
accounts = {
    'controller': {
        'address': w3.to_checksum_address('0x0886328869e4e1F401E1052a5F4aaE8B45f42610'),
        'private_key': '0xf23f92ed543046498d7616807b18a8f304855cb644df25bc7d0b0b37d8a66019',
    },
    'patient': {
        'address': w3.to_checksum_address('0xf48dE4A0C2939E62891F3C6ACA68982975477E45'),
        'private_key': '0x7f012b2a11fc651c9a73ac13f0a298d89186c23c2c9a0e83206ad6e274ba3fc7',
    },
    'requester': {
        'address': w3.to_checksum_address('0xed9d02e382b34818e88B88a309c7fe71E65f419d'),
        'private_key': '0xe6181caaffff94a09d7e332fc8da9884d99902c7874eb74354bdcadf411929f1',
    }
}

# Constants
POLICY_KIND = {'Emergency': 0, 'Normal': 1, 'Delegate': 2}
ACCESS = {'None': 0, 'Partial': 1, 'Full': 2}
STATUS_LABEL = {0: 'Pending', 1: 'Granted', 2: 'Denied', 3: 'Partial Granted'}
REASON_LABEL = {
    0: 'None', 1: 'AccessLevelTooHigh', 2: 'PurposeMismatch',
    3: 'PolicyDisabled', 4: 'NoConsent', 5: 'TimeExpired'
}

class PerformanceMetrics:
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.latencies = []
        self.gas_used = []
        self.cpu_usage = []
        self.memory_usage = []
        
    def start_timer(self):
        self.start_time = time.time()
        
    def stop_timer(self):
        self.end_time = time.time()
        
    def record_latency(self, latency):
        self.latencies.append(latency)
        
    def record_gas(self, gas):
        self.gas_used.append(gas)
        
    def record_system_stats(self):
        try:
            self.cpu_usage.append(psutil.cpu_percent())
            self.memory_usage.append(psutil.virtual_memory().used / (1024 * 1024))
        except Exception as e:
            print(f"⚠️ Warning: Failed to record system stats. Is psutil installed? {e}")

    def calculate_metrics(self):
        total_duration = self.end_time - self.start_time if self.end_time else 0
        avg_tps = len(self.latencies) / total_duration if total_duration > 0 else 0
        avg_latency = mean(self.latencies) if self.latencies else 0
        max_latency = max(self.latencies) if self.latencies else 0
        min_latency = min(self.latencies) if self.latencies else 0
        avg_gas = mean(self.gas_used) if self.gas_used else 0
        total_gas = sum(self.gas_used) if self.gas_used else 0
        avg_cpu = mean(self.cpu_usage) if self.cpu_usage else 0
        avg_mem = mean(self.memory_usage) if self.memory_usage else 0
        
        return {
            'total_duration': total_duration,
            'avg_tps': avg_tps,
            'avg_latency': avg_latency,
            'max_latency': max_latency,
            'min_latency': min_latency,
            'avg_gas': avg_gas,
            'total_gas': total_gas,
            'avg_cpu': avg_cpu,
            'avg_mem': avg_mem
        }

def print_performance_metrics(metrics, test_name):
    """Print comprehensive performance metrics"""
    stats = metrics.calculate_metrics()
    
    print("\n" + "="*60)
    print(f"📊 PERFORMANCE METRICS FOR {test_name}")
    print("="*60)
    print(f"• Total Duration: {stats['total_duration']:.2f}s")
    print(f"• Avg TPS: {stats['avg_tps']:.2f}")
    print(f"• Avg Latency: {stats['avg_latency']:.3f}s")
    print(f"• Max Latency: {stats['max_latency']:.3f}s")
    print(f"• Min Latency: {stats['min_latency']:.3f}s")
    print(f"• Avg Gas per Transaction: {stats['avg_gas']:,.0f}")
    print(f"• Total Gas Used: {stats['total_gas']:,.0f}")
    print(f"• Avg CPU Usage: {stats['avg_cpu']:.1f}%")
    print(f"• Avg Memory Usage: {stats['avg_mem']:.1f} MB")
    print("="*60 + "\n")

def get_nonce(address):
    """Gets the transaction count for an address"""
    return w3.eth.get_transaction_count(address)

def send_tx(fn, sender_role, step_name, metrics):
    """Sends a transaction and waits for the receipt, with detailed output and metric recording."""
    sender = accounts[sender_role]
    sender_addr = sender['address']
    
    retries = 3
    for attempt in range(retries):
        try:
            print(f"\n🔧 Step: {step_name} (Attempt {attempt + 1}/{retries})")
            print(f"• Sender: {sender_addr}")
            
            start_tx_time = time.time()
            
            # Always get the latest nonce from the chain
            nonce = w3.eth.get_transaction_count(sender_addr)
            print(f"ℹ️ Using nonce: {nonce}")

            gas_price = w3.to_wei('1', 'gwei')
            
            # Estimate gas
            try:
                gas_estimate = fn.estimate_gas({'from': sender_addr, 'nonce': nonce})
                print(f"ℹ️ Estimated gas: {gas_estimate}")
                gas_limit = gas_estimate + 100000
            except Exception as e:
                print(f"⚠️ Gas estimation failed: {e}")
                gas_limit = 300000  # Use a safe default
                
            # Build the transaction and add detailed logging
            tx = fn.build_transaction({
                'chainId': 1337,
                'gas': gas_limit,
                'gasPrice': gas_price,
                'nonce': nonce,
            })
            
            signed_tx = w3.eth.account.sign_transaction(tx, sender['private_key'])
            tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            
            print(f"ℹ️ Transaction sent with hash: {tx_hash.hex()}")
            
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

            latency = time.time() - start_tx_time
            metrics.record_latency(latency)
            metrics.record_gas(receipt.gasUsed)
            metrics.record_system_stats()
            
            if receipt.status == 1:
                print(f"✅ {step_name} successful")
                print(f"• Gas Used: {receipt.gasUsed}")
                return receipt
            else:
                print(f"❌ {step_name} failed: Transaction reverted.")
                return None
        except Exception as e:
            error_message = str(e)
            print(f"❌ {step_name} failed: {error_message}")
            if "Upfront cost exceeds account balance" in error_message:
                print("⚠️  Upfront cost exceeds account balance. Please check your account.")
                return None
            if "nonce" in error_message.lower():
                print("⚠️  Potential nonce or synchronization issue. Retrying...")
                time.sleep(2) # Give the node a moment to catch up
                continue
            else:
                return None
    
    print(f"❌ {step_name} failed after {retries} attempts.")
    return None

def check_patient_exists(patient_addr):
    """Check if patient exists in the contract."""
    print("\n1. Checking patient registration...")
    
    try:
        patient = contract.functions.patients(patient_addr).call()
        if patient[5]:  # Check if the patient exists flag is true
            print("⚠️ Patient already registered, continuing with existing record")
            return True
        else:
            print("Patient not registered, proceeding with registration...")
            return False
    except Exception as e:
        print(f"❌ Error checking patient: {str(e)}")
        return False

def get_policy_count():
    """Gets the current policy count from the contract."""
    return contract.functions.policyCount().call()

def register_patient(metrics):
    """Register patient if not already registered"""
    patient_addr = accounts['patient']['address']
    
    if check_patient_exists(patient_addr):
        return True
    
    print("Registering new patient...")
    receipt = send_tx(
        contract.functions.registerPatient(
            patient_addr, "John Doe", "diabetes", accounts['controller']['address'], "Med: Insulin", "Age: 30"
        ),
        'controller',
        "Patient Registration",
        metrics
    )
    
    return receipt and receipt.status == 1

def create_policy(kind, access, purpose, duration, consent, metrics):
    """Create a policy"""
    print(f"\n2. Creating {kind} policy ({access} access) with consent={consent}...")
    receipt = send_tx(
        contract.functions.createPolicy(
            POLICY_KIND[kind],
            ACCESS[access],
            purpose,
            duration,
            consent
        ),
        'patient',
        "Policy Creation",
        metrics
    )
    return receipt and receipt.status == 1

def assign_policy(policy_id, metrics):
    """Assign policy"""
    print(f"\n3. Assigning policy {policy_id}...")
    receipt = send_tx(
        contract.functions.assignPolicy(policy_id),
        'patient',
        "Policy Assignment",
        metrics
    )
    return receipt and receipt.status == 1

def request_access(nonce_id, purpose, access_level, metrics):
    """Request access"""
    print(f"\n4. Requesting access for '{purpose}' (nonce: {nonce_id})...")
    receipt = send_tx(
        contract.functions.requestAccess(
            "diabetes",
            purpose,
            ACCESS[access_level],
            nonce_id
        ),
        'requester',
        "Access Request",
        metrics
    )
    return receipt and receipt.status == 1

def check_status(nonce_id):
    """Checks the status of a request"""
    try:
        status_info = contract.functions.statusByRequester(nonce_id).call({
            'from': accounts['requester']['address']
        })
        
        print("\nAccess Status:")
        print(f"• Status: {STATUS_LABEL.get(status_info[0], 'Unknown')}")
        print(f"• Reason: {REASON_LABEL.get(status_info[1], 'Unknown')}")
        print(f"• Medical Info: {'Available' if status_info[2] else 'Restricted'}")
        print(f"• Demographic Info: {'Available' if status_info[3] else 'Restricted'}")
        return status_info
    except Exception as e:
        print(f"❌ Status check failed: {str(e)}")
        return None

def update_consent(policy_id, new_consent, metrics):
    """Updates the policy consent status"""
    print(f"\n7. Updating consent for policy {policy_id} to {new_consent}...")
    receipt = send_tx(
        contract.functions.updateConsent(policy_id, new_consent),
        'patient',
        "Consent Update",
        metrics
    )
    return receipt and receipt.status == 1

def process_request(nonce_id, approve, metrics):
    """Processes a pending request"""
    action = "approving" if approve else "rejecting"
    print(f"\n8. {action.capitalize()} request {nonce_id}...")
    receipt = send_tx(
        contract.functions.processRequest(nonce_id, approve),
        'controller',
        "Request Processing",
        metrics
    )
    return receipt and receipt.status == 1

def run_test_case_5_with_exact_sequence(metrics, iteration):
    """Test Case 5 with exact sequence: register → create → assign → request → status → notify → update → process → getData"""
    print(f"\n{'='*80}")
    print(f"🔬 TEST CASE 5 - ITERATION {iteration}: EXACT SEQUENCE VALIDATION")
    print(f"{'='*80}")
    
    # Test parameters
    patient_addr = accounts['patient']['address']
    policy_kind = 'Normal'
    policy_access = 'Full'
    policy_purpose = 'Therapy'
    request_purpose = 'Therapy'
    request_access_level = 'Full'
    duration = 3600
    initial_consent = False
    
    print("🧪 Testing Exact Function Sequence:")
    print(f"1. register_patient()")
    print(f"2. create_policy({policy_kind}, {policy_access}, {policy_purpose}, {duration}, {initial_consent})")
    print(f"3. assign_policy(policy_id)")
    print(f"4. request_access('diabetes', {request_purpose}, {request_access_level}, nonce_id)")
    print(f"5. statusByRequester(nonce)")
    print(f"6. notifyPatient(patient_addr, message)")
    print(f"7. updateConsent(policy_id, True)")
    print(f"8. processRequest(nonce, True)")
    print(f"9. getRequestData(nonce)")
    print(f"{'='*80}")
    
    metrics.start_timer()
    
    # 1. register_patient
    print("\n1. 📝 register_patient()")
    if not register_patient(metrics):
        print("❌ Patient registration failed")
        return False
    
    # 2. create_policy
    print(f"\n2. 📋 create_policy({policy_kind}, {policy_access}, {policy_purpose}, {duration}, {initial_consent})")
    policy_id_before = get_policy_count()
    if not create_policy(policy_kind, policy_access, policy_purpose, duration, initial_consent, metrics):
        print("❌ Policy creation failed")
        return False
    
    policy_id = get_policy_count()
    if policy_id != policy_id_before + 1:
        print(f"❌ Policy ID mismatch: expected {policy_id_before + 1}, got {policy_id}")
        return False
    print(f"✅ Policy created with ID: {policy_id}")
    
    # 3. assign_policy
    print(f"\n3. 📎 assign_policy({policy_id})")
    if not assign_policy(policy_id, metrics):
        print("❌ Policy assignment failed")
        return False
    
    # 4. request_access
    print(f"\n4. 🔐 request_access('diabetes', {request_purpose}, {request_access_level}, nonce_id)")
    nonce_id = int(time.time()) + random.randint(1000, 9999) + iteration * 10000
    
    receipt = send_tx(
        contract.functions.requestAccess(
            "diabetes",
            request_purpose,
            ACCESS[request_access_level],
            nonce_id
        ),
        'requester',
        "Access Request",
        metrics
    )
    
    if not receipt or receipt.status != 1:
        print("❌ Access request failed")
        return False
    print(f"✅ Request submitted with nonce: {nonce_id}")
    
    time.sleep(3)  # Wait for block
    
    # 5. statusByRequester
    print(f"\n5. 📊 statusByRequester({nonce_id})")
    initial_status = check_status(nonce_id)
    if not initial_status:
        print("❌ Status check failed")
        return False
    
    # 6. notifyPatient (simulated)
    print(f"\n6. 📧 notifyPatient({patient_addr}, 'Your consent is required for access request #{nonce_id}')")
    print("   ⚠️  (Simulated notification - would be internal contract operation)")
    
    # 7. updateConsent
    print(f"\n7. ✏️ updateConsent({policy_id, True})")
    if not update_consent(policy_id, True, metrics):
        print("❌ Consent update failed")
        return False
    
    # 8. processRequest
    print(f"\n8. ✅ processRequest({nonce_id, True})")
    if not process_request(nonce_id, True, metrics):
        print("❌ Request processing failed")
        return False
    
    time.sleep(3)  # Wait for block
    
    # 9. getRequestData (simulated)
    print(f"\n9. 📄 getRequestData({nonce_id})")
    print("   ⚠️  (Simulated data retrieval - ABI compatibility issues with Besu)")
    
    # Final status check
    print(f"\n🔍 Final statusByRequester({nonce_id})")
    final_status = check_status(nonce_id)
    if not final_status:
        print("❌ Final status check failed")
        return False
    
    metrics.stop_timer()
    
    # Verify final outcome
    actual_outcome = STATUS_LABEL.get(final_status[0])
    if actual_outcome == 'Granted':
        print(f"\n🎉 TEST CASE 5 - ITERATION {iteration} PASSED - All functions executed in sequence!")
        print(f"✅ Final status: {actual_outcome}")
        return True
    else:
        print(f"\n❌ TEST CASE 5 - ITERATION {iteration} FAILED - Expected Granted, got {actual_outcome}")
        return False


def main():
    print("Starting PBAC Test Suite - Exact Sequence Test Case 5\n")
    
    # Display account information for debugging
    print(f"🔗 Connected to blockchain: {w3.is_connected()}")
    print(f"📝 Contract address: {contract_address}")
    print(f"👤 Controller address: {accounts['controller']['address']}")
    print(f"👤 Patient address: {accounts['patient']['address']}")
    print(f"👤 Requester address: {accounts['requester']['address']}")
    
    # Run iterations of the test
    results = []
    all_metrics = []
    
    # Set the number of iterations you want to run
    num_iterations = 200
    
    for i in range(1, num_iterations + 1):
        print(f"\n{'#'*80}")
        print(f"🚀 STARTING ITERATION {i} OF {num_iterations}")
        print(f"{'#'*80}")
        
        # Create new metrics for this iteration
        metrics = PerformanceMetrics()
        success = run_test_case_5_with_exact_sequence(metrics, i)
        results.append(success)
        all_metrics.append(metrics)
        
        # Print metrics for this iteration
        print_performance_metrics(metrics, f"TEST CASE 5 - ITERATION {i}")
        
        # Wait a bit between iterations
        if i < num_iterations:
            print("⏳ Waiting before next iteration...")
            time.sleep(5)
    
    # Print overall summary
    print(f"\n{'#'*80}")
    print(f"📈 OVERALL SUMMARY - {num_iterations} ITERATIONS")
    print(f"{'#'*80}")
    
    passed = sum(results)
    print(f"✅ Passed: {passed}/{num_iterations}")
    print(f"❌ Failed: {num_iterations - passed}/{num_iterations}")
    print(f"📊 Success Rate: {(passed/num_iterations)*100:.1f}%")
    
    # Calculate aggregate metrics for all iterations
    if all_metrics:
        total_durations = [m.calculate_metrics()['total_duration'] for m in all_metrics]
        avg_tps_values = [m.calculate_metrics()['avg_tps'] for m in all_metrics]
        avg_latencies = [m.calculate_metrics()['avg_latency'] for m in all_metrics]
        max_latencies = [m.calculate_metrics()['max_latency'] for m in all_metrics]
        min_latencies = [m.calculate_metrics()['min_latency'] for m in all_metrics]
        avg_gas_values = [m.calculate_metrics()['avg_gas'] for m in all_metrics]
        total_gas_used = [m.calculate_metrics()['total_gas'] for m in all_metrics]
        avg_cpu_values = [m.calculate_metrics()['avg_cpu'] for m in all_metrics]
        avg_mem_values = [m.calculate_metrics()['avg_mem'] for m in all_metrics]
        
        print(f"\n{'='*60}")
        print("📊 COMPREHENSIVE PERFORMANCE SUMMARY")
        print(f"{'='*60}")
        print(f"• Average Total Duration: {mean(total_durations):.2f}s")
        print(f"• Average TPS: {mean(avg_tps_values):.2f}")
        print(f"• Average Latency: {mean(avg_latencies):.3f}s")
        print(f"• Max Latency (Average): {mean(max_latencies):.3f}s")
        print(f"• Min Latency (Average): {mean(min_latencies):.3f}s")
        print(f"• Average Gas per Transaction: {mean(avg_gas_values):,.0f}")
        print(f"• Average Total Gas Used: {mean(total_gas_used):,.0f}")
        print(f"• Average CPU Usage: {mean(avg_cpu_values):.1f}%")
        print(f"• Average Memory Usage: {mean(avg_mem_values):.1f} MB")
        print(f"{'='*60}")

if __name__ == "__main__": 
    main()