from web3 import Web3
from eth_account import Account
import time

# 1. Connect to your Besu node
w3 = Web3(Web3.HTTPProvider('http://localhost:8545'))

if w3.is_connected():
    print("Connected to Besu node!")
else:
    print("Connection failed!")
    exit()

# Define all accounts by private key only - let Web3 derive the addresses
accounts = {
    'controller': {
        'private_key': '0xe6181caaffff94a09d7e332fc8da9884d99902c7874eb74354bdcadf411929f1',
    },
    'patient': {
        'private_key': '0x7f012b2a11fc651c9a73ac13f0a298d89186c23c2c9a0e83206ad6e274ba3fc7',
    },
    'requester': {
        'private_key': '0xf23f92ed543046498d7616807b18a8f304855cb644df25bc7d0b0b37d8a66019',
    },
    'unauthorized': {
        'private_key': '0x5ad8b28507578c429dfa9f178d7f742f4861716ee956eb75648a7dbc5ffe915d',
    }
}

# Derive addresses from private keys
for role, account in accounts.items():
    account_obj = Account.from_key(account['private_key'])
    account['address'] = w3.to_checksum_address(account_obj.address)
    account['account_obj'] = account_obj

def send_transaction(sender_role, recipient_role, amount_eth=0.1):
    """Send a transaction from one account to another"""
    print(f"\n{'='*50}")
    print(f"Sending transaction from {sender_role} to {recipient_role}")
    print(f"{'='*50}")
    
    sender = accounts[sender_role]
    recipient_address = accounts[recipient_role]['address']
    
    try:
        sender_address = sender['address']
        
        # Get transaction parameters
        current_nonce = w3.eth.get_transaction_count(sender_address)
        current_gas_price = w3.eth.gas_price
        current_chain_id = w3.eth.chain_id

        print(f"Sender: {sender_address}")
        print(f"Recipient: {recipient_address}")
        print(f"Current Nonce: {current_nonce}")
        print(f"Gas Price: {w3.from_wei(current_gas_price, 'gwei')} Gwei")
        print(f"Chain ID: {current_chain_id}")

        amount_to_send_wei = w3.to_wei(amount_eth, 'ether')

        # Build the transaction
        transaction = {
            'to': recipient_address,
            'value': amount_to_send_wei,
            'gas': 21000,
            'gasPrice': current_gas_price,
            'nonce': current_nonce,
            'chainId': current_chain_id
        }

        # Sign the transaction
        signed_transaction = sender['account_obj'].sign_transaction(transaction)

        # Send the transaction
        tx_hash = w3.eth.send_raw_transaction(signed_transaction.raw_transaction)

        print("Transaction sent successfully!")
        print(f"Transaction Hash: {tx_hash.hex()}")
        
        # Wait for transaction to be mined
        print("Waiting for transaction to be mined...")
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
        
        if receipt.status == 1:
            print("✅ Transaction successful!")
            print(f"Gas used: {receipt.gasUsed}")
        else:
            print("❌ Transaction failed!")
            
        return True
        
    except Exception as e:
        print(f"❌ An error occurred: {e}")
        return False

def check_balances():
    """Check balances of all accounts"""
    print(f"\n{'='*40}")
    print("ACCOUNT BALANCES")
    print(f"{'='*40}")
    
    for role, account in accounts.items():
        balance = w3.eth.get_balance(account['address'])
        print(f"{role:12}: {w3.from_wei(balance, 'ether'):.6f} ETH - {account['address']}")
    
    print(f"{'='*40}")

def check_nonces():
    """Check nonces of all accounts"""
    print(f"\n{'='*40}")
    print("ACCOUNT NONCES")
    print(f"{'='*40}")
    
    for role, account in accounts.items():
        nonce = w3.eth.get_transaction_count(account['address'])
        print(f"{role:12}: {nonce} - {account['address']}")
    
    print(f"{'='*40}")

# Main execution
if __name__ == "__main__":
    # First, let's see what addresses these private keys actually correspond to
    print("Actual addresses derived from private keys:")
    for role, account in accounts.items():
        addr = account['address']
        print(f"{role:12}: {addr}")
    
    # Check initial balances and nonces
    check_balances()
    check_nonces()
    
    # Send transactions to increase nonces
    transactions = [
        ('controller', 'patient', 50),
        ('controller', 'requester', 50),
        ('controller', 'unauthorized', 50),
        ('patient', 'requester', 50),
        ('requester', 'patient', 50),
        ('unauthorized', 'controller', 50),
    ]
    
    for sender, recipient, amount in transactions:
        send_transaction(sender, recipient, amount)
        time.sleep(2)  # Wait a bit between transactions
    
    # Check final balances and nonces
    print("\n" + "="*60)
    print("FINAL RESULTS")
    print("="*60)
    check_balances()
    check_nonces()