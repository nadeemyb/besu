from web3 import Web3
import json
import time
import random

# Initialize Web3 connection
w3 = Web3(Web3.HTTPProvider("http://localhost:8545"))
if not w3.is_connected():
    print("❌ Failed to connect to Ethereum node")
    exit()

# Load contract ABI
try:
    with open("PBACSystem_abi.json") as f:
        contract_abi = json.load(f)
except Exception as e:
    print(f"❌ Failed to load ABI: {e}")
    exit()

# Contract setup
contract_address = "0xfeae27388A65eE984F452f86efFEd42AaBD438FD"
contract = w3.eth.contract(address=contract_address, abi=contract_abi)
print("⚠️ Skipping contract verification for Besu compatibility")

# Accounts configuration
accounts = {
    'controller': {
        'address': '0xFE3B557E8Fb62b89F4916B721be55cEb828dBd73',
        'private_key': '0x8f2a55949038a9610f50fb23b5883af3b4ecb3c3bb792cbcefbd1542c692be63',
    },
    'patient': {
        'address': '0x627306090abaB3A6e1400e9345bC60c78a8BEf57',
        'private_key': '0xc87509a1c067bbde78beb793e6fa76530b6382a4c0241e5e4a9ec0a0f44dc0d3',
    },
    'requester': {
        'address': '0xf17f52151EbEF6C7334FAD080c5704D77216b732',
        'private_key': '0xae6ae8e5ccbfb04590405997ee2d52d2b330726137b875053c36d94e974d162f',
    },
}

# Constants
POLICY_KIND = {'Emergency': 0, 'Normal': 1, 'Delegate': 2}
ACCESS = {'None': 0, 'Partial': 1, 'Full': 2}
STATUS_LABEL = {0: 'Pending', 1: 'Granted', 2: 'Denied'}
REASON_LABEL = {
    0: 'None', 1: 'AccessLevelTooHigh', 2: 'PurposeMismatch',
    3: 'PolicyDisabled', 4: 'NoConsent', 5: 'TimeExpired'
}

def send_tx(fn, sender_role, step_name, gas=500000):
    """Send transaction with proper error handling"""
    sender = accounts[sender_role]
    
    try:
        tx = fn.build_transaction({
            'chainId': 1337,
            'gas': gas,
            'gasPrice': w3.to_wei('20', 'gwei'),
            'nonce': w3.eth.get_transaction_count(sender['address']),
        })
        
        signed_tx = w3.eth.account.sign_transaction(tx, sender['private_key'])
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        
        if receipt.status == 1:
            print(f"✅ {step_name} successful (tx: {tx_hash.hex()})")
            return receipt
        else:
            print(f"❌ {step_name} failed: Transaction reverted.")
            return None
    except Exception as e:
        print(f"❌ {step_name} failed: {str(e)}")
        return None

def check_patient_exists(patient_addr):
    """Check if patient exists"""
    try:
        patient = contract.functions.patients(patient_addr).call()
        return patient[0]  # exists flag
    except Exception as e:
        print(f"❌ Error checking patient: {str(e)}")
        return False

def register_patient():
    """Register patient if not already registered"""
    patient_addr = accounts['patient']['address']
    print("\n1. Checking patient registration...")
    
    if check_patient_exists(patient_addr):
        print("⚠️ Patient already registered, continuing with existing record")
        return True
    
    print("Registering new patient...")
    receipt = send_tx(
        contract.functions.registerPatient(
            patient_addr,
            "John Doe",
            "diabetes",
            '0x0000000000000000000000000000000000000000', # Dummy address since delegate is not used
            "Med: X",
            "Age: 30"
        ),
        'controller',
        "Patient Registration"
    )
    return receipt and receipt.status == 1

def create_policy(kind, access, purpose, duration, consent, creator_role):
    """Create policy with given parameters"""
    print(f"\n2. Creating {kind} policy ({access} access)...")
    receipt = send_tx(
        contract.functions.createPolicy(
            POLICY_KIND[kind],
            ACCESS[access],
            purpose,
            duration,
            consent
        ),
        creator_role,
        "Policy Creation"
    )
    return receipt and receipt.status == 1

def assign_policy(policy_id, assigner_role):
    """Assign policy"""
    print(f"\n3. Assigning policy {policy_id}...")
    try:
        receipt = send_tx(
            contract.functions.assignPolicy(policy_id),
            assigner_role,
            "Policy Assignment"
        )
        return receipt and receipt.status == 1
    except Exception as e:
        print(f"❌ Policy assignment failed: {str(e)}")
        return False

def request_access(nonce_id, purpose, access_level):
    """Request access with specified purpose and access level"""
    print(f"\n4. Requesting access for '{purpose}' (nonce: {nonce_id})...")
    receipt = send_tx(
        contract.functions.requestAccess(
            "diabetes",
            purpose,
            ACCESS[access_level],
            nonce_id
        ),
        'requester',
        "Access Request"
    )
    return receipt and receipt.status == 1

def check_status(nonce_id):
    """Check access request status with proper permissions."""
    try:
        status_info = contract.functions.statusByRequester(nonce_id).call({
            'from': accounts['requester']['address']
        })
        
        print("\nAccess Status:")
        print(f"• Status: {STATUS_LABEL[status_info[0]]}")
        print(f"• Reason: {REASON_LABEL[status_info[1]]}")
        print(f"• Medical Info: {'Available' if status_info[2] else 'Restricted'}")
        print(f"• Demographic Info: {'Available' if status_info[3] else 'Restricted'}")
        return status_info
    except Exception as e:
        print(f"❌ Status check failed: {str(e)}")
        return None

def run_test_scenario(scenario, test_num):
    """Runs a single test scenario based on the provided table."""
    kind, policy_access, policy_purpose, consent, requester_access, request_purpose, duration, expected_status, expected_reason, expected_medical, expected_demo = scenario
    
    print(f"\n{'='*50}")
    print(f"🚀 Running Test #{test_num}: {kind} {policy_purpose} ({policy_access} policy)")
    print(f"Expected: {expected_status} ({expected_reason})")
    print(f"{'='*50}")
    
    if not register_patient():
        print("❌ Cannot proceed - patient registration failed")
        return False
    
    # Emergency policies are created by the requester, not the patient
    creator_role = 'requester'
    assigner_role = 'patient'
    
    if not create_policy(kind, policy_access, policy_purpose, duration, consent, creator_role):
        print("❌ Policy creation failed")
        return False
    
    policy_id = contract.functions.policyCount().call()
    if not assign_policy(policy_id, assigner_role):
        print("❌ Policy assignment failed")
        return False
    
    nonce_id = int(time.time()) + random.randint(1, 10000)
    if not request_access(nonce_id, request_purpose, requester_access):
        print("❌ Access request failed")
        return False
    
    print("\n⏳ Waiting for transactions to finalize...")
    time.sleep(3)
    
    status_info = check_status(nonce_id)
    if not status_info:
        return False
    
    current_status_label = STATUS_LABEL[status_info[0]]
    current_reason_label = REASON_LABEL[status_info[1]]
    
    status_match = current_status_label == expected_status
    reason_match = current_reason_label == expected_reason
    medical_match = (status_info[2] and expected_medical == "Available") or (not status_info[2] and expected_medical == "Restricted")
    demo_match = (status_info[3] and expected_demo == "Available") or (not status_info[3] and expected_demo == "Restricted")
    
    if status_match and reason_match and medical_match and demo_match:
        print(f"\n✅ Test #{test_num} PASSED - Result matches expected.")
        return True
    else:
        print(f"\n❌ Test #{test_num} FAILED - Mismatched outcomes.")
        print(f"  - Status: Expected '{expected_status}', Got '{current_status_label}'")
        print(f"  - Reason: Expected '{expected_reason}', Got '{current_reason_label}'")
        print(f"  - Medical: Expected '{expected_medical}', Got '{'Available' if status_info[2] else 'Restricted'}'")
        print(f"  - Demo: Expected '{expected_demo}', Got '{'Available' if status_info[3] else 'Restricted'}'")
        return False

def main():
    test_scenarios = [
        # kind, policy_access, policy_purpose, consent, requester_access, request_purpose, duration, expected_status, expected_reason, expected_medical, expected_demo
        ("Emergency", "Full", "EmergencyCare", True, "Full", "EmergencyCare", 3600, "Granted", "None", "Available", "Available"),
        ("Emergency", "Partial", "Triage", True, "Full", "Triage", 7200, "Pending", "PurposeMismatch", "Restricted", "Restricted")
    ]
    
    print("Starting PBAC Test Suite (2 Emergency Scenarios)\n")
    
    granted_count = 0
    denied_count = 0
    pending_count = 0
    
    results = []
    for i, scenario in enumerate(test_scenarios, 1):
        test_passed = run_test_scenario(scenario, i)
        results.append(test_passed)
        if test_passed:
            if scenario[7] == 'Granted':
                granted_count += 1
            elif scenario[7] == 'Denied':
                denied_count += 1
            elif scenario[7] == 'Pending':
                pending_count += 1
        time.sleep(2)
    
    print("\nTest Summary:")
    print(f"Tests Passed: {sum(results)}/2")
    print(f"Granted: {granted_count}, Denied: {denied_count}, Pending: {pending_count}")

if __name__ == "__main__":
    main()