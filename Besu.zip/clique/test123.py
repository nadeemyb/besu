import json
import time
import random
import psutil
from statistics import mean
from web3 import Web3

# Initialize Web3 connection
w3 = Web3(Web3.HTTPProvider("http://localhost:8545"))
if not w3.is_connected():
    print("❌ Failed to connect to Ethereum node")
    exit()

# Load contract ABI
try:
    with open("PBACSystem_abi.json") as f:
        contract_abi = json.load(f)
except Exception as e:
    print(f"❌ Failed to load ABI: {e}")
    exit()

# Contract setup
contract_address = "0x1932c48b2bF8102Ba33B4A6B545C32236e342f34"
contract = w3.eth.contract(address=contract_address, abi=contract_abi)

# Accounts configuration - CORRECTED CONTROLLER ADDRESS
accounts = {
    'controller': {
        'address': w3.to_checksum_address('0xed9d02e382b34818e88B88a309c7fe71E65f419d'),
        'private_key': '0xe6181caaffff94a09d7e332fc8da9884d99902c7874eb74354bdcadf411929f1',
        
    },
    'patient': {
        'address': w3.to_checksum_address('0xf48dE4A0C2939E62891F3C6ACA68982975477E45'),
        'private_key': '0x7f012b2a11fc651c9a73ac13f0a298d89186c23c2c9a0e83206ad6e274ba3fc7',
    },
    'requester': {
        'address': w3.to_checksum_address('0x0886328869e4e1F401E1052a5F4aaE8B45f42610'),
        'private_key': '0xf23f92ed543046498d7616807b18a8f304855cb644df25bc7d0b0b37d8a66019',
    }
}

# Constants
POLICY_KIND = {'Emergency': 0, 'Normal': 1, 'Delegate': 2}
ACCESS = {'None': 0, 'Partial': 1, 'Full': 2}
STATUS_LABEL = {0: 'Pending', 1: 'Granted', 2: 'Denied', 3: 'Partial Granted'}
REASON_LABEL = {
    0: 'None', 
    1: 'PurposeMismatch', 
    2: 'AccessLevelTooHigh', 
    3: 'ConsentNotGranted',
    4: 'PolicyInactive', 
    5: 'PolicyExpired', 
    6: 'NotDelegate',
    7: 'InvalidPolicyType', 
    8: 'RequestAlreadyProcessed',
    9: 'PatientDoesNotExist',
    10: 'InvalidRequest',
    11: 'NeedApproval'
}

class TestCaseMetrics:
    def __init__(self, test_name):
        self.test_name = test_name
        self.results = []  # List of (success, metrics) for each run
        self.pass_count = 0
        self.fail_count = 0
        
    def add_result(self, success, metrics):
        self.results.append((success, metrics))
        if success:
            self.pass_count += 1
        else:
            self.fail_count += 1
            
    def calculate_aggregate_metrics(self):
        if not self.results:
            return None
            
        total_durations = []
        total_gas_used = []
        avg_latencies = []
        tps_values = []
        avg_cpu_usages = []
        avg_mem_usages = []
        
        for success, metrics in self.results:
            metrics_data = metrics.calculate_metrics()
            total_durations.append(metrics_data['total_duration'])
            total_gas_used.append(metrics_data['total_gas'])
            avg_latencies.append(metrics_data['avg_latency'])
            tps_values.append(metrics_data['tps'])
            avg_cpu_usages.append(metrics_data['avg_cpu'])
            avg_mem_usages.append(metrics_data['avg_mem'])
        
        return {
            'avg_total_duration': mean(total_durations) if total_durations else 0,
            'avg_total_gas': mean(total_gas_used) if total_gas_used else 0,
            'avg_latency': mean(avg_latencies) if avg_latencies else 0,
            'avg_tps': mean(tps_values) if tps_values else 0,
            'avg_cpu': mean(avg_cpu_usages) if avg_cpu_usages else 0,
            'avg_mem': mean(avg_mem_usages) if avg_mem_usages else 0,
            'min_latency': min(avg_latencies) if avg_latencies else 0,
            'max_latency': max(avg_latencies) if avg_latencies else 0,
            'success_rate': (self.pass_count / len(self.results)) * 100 if self.results else 0
        }

class ScenarioMetrics:
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.latencies = []
        self.gas_used = []
        self.cpu_usage = []
        self.memory_usage = []
        
    def start_timer(self):
        self.start_time = time.time()
        
    def stop_timer(self):
        self.end_time = time.time()
        
    def record_metrics(self, latency, gas, cpu, memory):
        self.latencies.append(latency)
        self.gas_used.append(gas)
        self.cpu_usage.append(cpu)
        self.memory_usage.append(memory)
        
    def calculate_metrics(self):
        total_duration = self.end_time - self.start_time if self.end_time else 0
        total_gas = sum(self.gas_used) if self.gas_used else 0
        avg_latency = mean(self.latencies) if self.latencies else 0
        avg_cpu = mean(self.cpu_usage) if self.cpu_usage else 0
        avg_mem = mean(self.memory_usage) if self.memory_usage else 0
        tps = len(self.latencies) / total_duration if total_duration > 0 else 0
        
        return {
            'total_duration': total_duration,
            'total_gas': total_gas,
            'avg_latency': avg_latency,
            'tps': tps,
            'avg_cpu': avg_cpu,
            'avg_mem': avg_mem
        }

def send_tx(fn, sender_role, step_name=""):
    """Sends a transaction and waits for the receipt with better error handling"""
    sender = accounts[sender_role]
    sender_addr = sender['address']
    
    try:
        print(f"\n🔧 Attempting: {step_name}")
        print(f"• From: {sender_addr}")
        
        nonce = w3.eth.get_transaction_count(sender_addr)
        #gas_price = w3.to_wei('100', 'gwei')
        gas_price = w3.to_wei('1', 'gwei')
        # Estimate gas
        try:
            gas_estimate = fn.estimate_gas({'from': sender_addr, 'nonce': nonce})
            print(f"ℹ️ Estimated gas: {gas_estimate}")
            gas_limit = gas_estimate + 100000
        except Exception as e:
            print(f"⚠️ Gas estimation failed: {e}")
            gas_limit = 300000
            
        # Build and send transaction
        tx = fn.build_transaction({
            'chainId': 1337,
            'gas': gas_limit,
            'gasPrice': gas_price,
            'nonce': nonce,
        })
        
        signed_tx = w3.eth.account.sign_transaction(tx, sender['private_key'])
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"ℹ️ Transaction sent: {tx_hash.hex()}")
        
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
        
        if receipt.status == 1:
            print(f"✅ {step_name} successful")
            print(f"• Gas used: {receipt.gasUsed}")
            return receipt, receipt.gasUsed
        else:
            print(f"❌ {step_name} failed: Transaction reverted")
            return None, 0
            
    except Exception as e:
        print(f"❌ {step_name} failed: {str(e)}")
        return None, 0

def check_patient_exists(patient_addr):
    """Check if patient exists in the contract with better error handling"""
    try:
        print(f"\n🔍 Checking if patient exists: {patient_addr}")
        patient = contract.functions.patients(patient_addr).call()
        exists = patient[5]  # Check if the patient exists flag is true
        
        if exists:
            print("✅ Patient already registered")
        else:
            print("ℹ️ Patient not registered yet")
            
        return exists
        
    except Exception as e:
        print(f"❌ Error checking patient: {str(e)}")
        return False

def get_policy_count():
    """Gets the current policy count from the contract."""
    try:
        return contract.functions.policyCount().call()
    except:
        return 0

def register_patient(metrics):
    """Register patient if not already registered"""
    patient_addr = accounts['patient']['address']
    
    if check_patient_exists(patient_addr):
        return True
    
    print("\n👤 Registering new patient...")
    start_time = time.time()
    
    receipt, gas_used = send_tx(
        contract.functions.registerPatient(
            patient_addr, "John Doe", "diabetes", accounts['controller']['address'], "Med: Insulin", "Age: 30"
        ),
        'controller',
        "Patient Registration"
    )
    
    if receipt and receipt.status == 1:
        latency = time.time() - start_time
        metrics.record_metrics(latency, gas_used, psutil.cpu_percent(), psutil.virtual_memory().used / (1024 * 1024))
        return True
    
    print("❌ Patient registration failed")
    return False

def create_policy(kind, access, purpose, duration, consent, metrics):
    """Create a policy"""
    start_time = time.time()
    receipt, gas_used = send_tx(
        contract.functions.createPolicy(
            POLICY_KIND[kind],
            ACCESS[access],
            purpose,
            duration,
            consent
        ),
        'patient',
        f"Policy Creation ({kind}, {access})"
    )
    
    if receipt and receipt.status == 1:
        latency = time.time() - start_time
        metrics.record_metrics(latency, gas_used, psutil.cpu_percent(), psutil.virtual_memory().used / (1024 * 1024))
        return True
    
    return False

def assign_policy(policy_id, metrics):
    """Assign policy"""
    start_time = time.time()
    receipt, gas_used = send_tx(
        contract.functions.assignPolicy(policy_id),
        'patient',
        f"Policy Assignment #{policy_id}"
    )
    
    if receipt and receipt.status == 1:
        latency = time.time() - start_time
        metrics.record_metrics(latency, gas_used, psutil.cpu_percent(), psutil.virtual_memory().used / (1024 * 1024))
        return True
    
    return False

def request_access(nonce_id, purpose, access_level, metrics):
    """Request access"""
    start_time = time.time()
    receipt, gas_used = send_tx(
        contract.functions.requestAccess(
            "diabetes",
            purpose,
            ACCESS[access_level],
            nonce_id
        ),
        'requester',
        f"Access Request ({purpose}, {access_level})"
    )
    
    if receipt and receipt.status == 1:
        latency = time.time() - start_time
        metrics.record_metrics(latency, gas_used, psutil.cpu_percent(), psutil.virtual_memory().used / (1024 * 1024))
        return True
    
    return False

def check_status(nonce_id):
    """Checks the status of a request"""
    try:
        status_info = contract.functions.statusByRequester(nonce_id).call({
            'from': accounts['requester']['address']
        })
        return status_info
    except Exception as e:
        print(f"❌ Status check failed: {str(e)}")
        return None

def run_test_scenario(scenario, test_num, iteration):
    """Runs a single test scenario"""
    (policy_kind, policy_purpose, initial_consent, policy_access, 
     request_access_level, request_purpose, duration, 
     expected_outcome, expected_medical, expected_demo, 
     expected_reason, special_flags) = scenario.values()

    print(f"\n{'='*60}")
    print(f"🚀 Running Test #{test_num} (Iteration {iteration}): {policy_kind} ({policy_purpose})")
    print(f"Expected: {expected_outcome} ({expected_reason})")
    print(f"{'='*60}")

    metrics = ScenarioMetrics()
    metrics.start_timer()

    # 1. Register the patient
    if not register_patient(metrics):
        print("❌ Cannot proceed - patient registration failed")
        return False, metrics
    
    current_policy_count = get_policy_count()
    policy_id = current_policy_count + 1
    print(f"📋 Next policy ID: {policy_id}")
    
    # 2. Create and assign a policy
    if not create_policy(policy_kind, policy_access, policy_purpose, duration, initial_consent, metrics):
        print("❌ Policy creation failed")
        return False, metrics
    
    if not assign_policy(policy_id, metrics):
        print("❌ Policy assignment failed")
        return False, metrics
    
    # 3. Request access
    nonce_id = int(time.time()) + random.randint(1, 10000) + iteration * 10000
    if not request_access(nonce_id, request_purpose, request_access_level, metrics):
        print("❌ Access request failed")
        return False, metrics
    
    print("\n⏳ Waiting for transactions to finalize...")
    time.sleep(3)
    
    # Check final status
    final_status = check_status(nonce_id)
    
    metrics.stop_timer()
    
    if final_status:
        actual_outcome = STATUS_LABEL.get(final_status[0])
        actual_reason = REASON_LABEL.get(final_status[1])
        
        # Handle Pending status for medical and demographic data
        if actual_outcome == 'Pending':
            actual_medical = 'Pending'
            actual_demo = 'Pending'
        else:
            actual_medical = 'Available' if final_status[2] else 'Restricted'
            actual_demo = 'Available' if final_status[3] else 'Restricted'

        status_match = actual_outcome == expected_outcome
        reason_match = actual_reason == expected_reason
        medical_match = actual_medical == expected_medical
        demo_match = actual_demo == expected_demo
        
        if status_match and reason_match and medical_match and demo_match:
            print(f"✅ Test #{test_num} (Iteration {iteration}) PASSED - Result matches expected.")
            return True, metrics
        else:
            print(f"❌ Test #{test_num} (Iteration {iteration}) FAILED - Mismatched outcomes.")
            print(f"  - Status: Expected '{expected_outcome}', Got '{actual_outcome}'")
            print(f"  - Reason: Expected '{expected_reason}', Got '{actual_reason}'")
            print(f"  - Medical: Expected '{expected_medical}', Got '{actual_medical}'")
            print(f"  - Demographic: Expected '{expected_demo}', Got '{actual_demo}'")
            return False, metrics
    
    print(f"❌ Test #{test_num} (Iteration {iteration}) FAILED - Could not retrieve status.")
    return False, metrics

def main():
    test_scenarios = [
        # Test 1: Treatment with consent - INSTANT GRANT
        # {
        #     'policy_kind': 'Normal', 'policy_purpose': 'Treatment', 'initial_consent': True, 
        #     'policy_access': 'Full', 'request_access_level': 'Full', 'request_purpose': 'Treatment',
        #     'duration': 2592000, 'expected_outcome': 'Granted', 'expected_medical': 'Available',
        #     'expected_demo': 'Available', 'expected_reason': 'None', 'special_flags': '-'
        # },
        # # Test 2: Checkup with partial policy - PARTIAL GRANT
        # {
        #     'policy_kind': 'Normal', 'policy_purpose': 'Checkup', 'initial_consent': True, 
        #     'policy_access': 'Partial', 'request_access_level': 'Partial', 'request_purpose': 'Checkup',
        #     'duration': 604800, 'expected_outcome': 'Partial Granted', 'expected_medical': 'Available',
        #     'expected_demo': 'Restricted', 'expected_reason': 'None', 'special_flags': '-'
        # },
        # Test 3: Audit without consent - IMMEDIATE DENIAL
        {
            'policy_kind': 'Normal', 'policy_purpose': 'Audit', 'initial_consent': False, 
            'policy_access': 'None', 'request_access_level': 'Full', 'request_purpose': 'Audit',
            'duration': 86400, 'expected_outcome': 'Denied', 'expected_medical': 'Restricted',
            'expected_demo': 'Restricted', 'expected_reason': 'AccessLevelTooHigh', 'special_flags': '-'
        }
    ]
    
    print("Starting PBAC Test Suite for Three Specific Scenarios (5 Iterations)\n")
    
    # First, check blockchain connection
    print(f"🔗 Connected to blockchain: {w3.is_connected()}")
    print(f"📝 Contract address: {contract_address}")
    print(f"👤 Controller address: {accounts['controller']['address']}")
    print(f"👤 Patient address: {accounts['patient']['address']}")
    
    # Check balances
    controller_balance = w3.eth.get_balance(accounts['controller']['address'])
    patient_balance = w3.eth.get_balance(accounts['patient']['address'])
    print(f"💰 Controller balance: {w3.from_wei(controller_balance, 'ether')} ETH")
    print(f"💰 Patient balance: {w3.from_wei(patient_balance, 'ether')} ETH")
    
    # Initialize test case trackers
    test_case_metrics = [
        TestCaseMetrics("Test 1: Treatment with Consent"),
        TestCaseMetrics("Test 2: Checkup with Partial Policy"), 
        TestCaseMetrics("Test 3: Audit without Consent")
    ]
    
    # Run 5 iterations of all test scenarios
    num_iterations = 50
    
    for iteration in range(1, num_iterations + 1):
        print(f"\n{'#'*80}")
        print(f"🏁 STARTING ITERATION {iteration} OF {num_iterations}")
        print(f"{'#'*80}")
        
        for i, scenario in enumerate(test_scenarios):
            success, metrics = run_test_scenario(scenario, i+1, iteration)
            test_case_metrics[i].add_result(success, metrics)
            
            # Print iteration metrics
            metrics_data = metrics.calculate_metrics()
            print(f"\n{'='*80}")
            print(f"📊 ITERATION {iteration} METRICS FOR: Test #{i+1}")
            print(f"{'='*80}")
            print(f"• Success: {'✅' if success else '❌'}")
            print(f"• Total Duration: {metrics_data['total_duration']:.2f}s")
            print(f"• Total Gas Used: {metrics_data['total_gas']:,.0f}")
            print(f"• Avg Latency: {metrics_data['avg_latency']:.3f}s")
            print(f"• Overall TPS: {metrics_data['tps']:.3f}")
            print(f"• Avg CPU Usage: {metrics_data['avg_cpu']:.1f}%")
            print(f"• Avg Memory Usage: {metrics_data['avg_mem']:.1f} MB")
            print(f"{'='*80}\n")
            
            time.sleep(2)
    
    # Print overall summary for each test case
    print(f"\n{'#'*80}")
    print(f"📈 FINAL SUMMARY AFTER {num_iterations} ITERATIONS")
    print(f"{'#'*80}")
    
    for i, test_metrics in enumerate(test_case_metrics):
        aggregate = test_metrics.calculate_aggregate_metrics()
        
        print(f"\n{'='*80}")
        print(f"📊 {test_metrics.test_name} - {test_metrics.pass_count}/{num_iterations} PASSED")
        print(f"{'='*80}")
        print(f"• Success Rate: {aggregate['success_rate']:.1f}%")
        print(f"• Avg Total Duration: {aggregate['avg_total_duration']:.2f}s")
        print(f"• Avg Total Gas Used: {aggregate['avg_total_gas']:,.0f}")
        print(f"• Avg Latency: {aggregate['avg_latency']:.3f}s")
        print(f"• Min Latency: {aggregate['min_latency']:.3f}s")
        print(f"• Max Latency: {aggregate['max_latency']:.3f}s")
        print(f"• Avg TPS: {aggregate['avg_tps']:.3f}")
        print(f"• Avg CPU Usage: {aggregate['avg_cpu']:.1f}%")
        print(f"• Avg Memory Usage: {aggregate['avg_mem']:.1f} MB")
        print(f"{'='*80}")

if __name__ == "__main__": 
    main()