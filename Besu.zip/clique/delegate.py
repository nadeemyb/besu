from web3 import Web3
import json
import time
import random

# Initialize Web3 connection
# IMPORTANT: Ensure your local Besu node is running on this address.
w3 = Web3(Web3.HTTPProvider("http://localhost:8545"))
if not w3.is_connected():
    print("❌ Failed to connect to Ethereum node")
    exit()

# Load contract ABI
try:
    with open("PBACSystem_abi.json") as f:
        contract_abi = json.load(f)
except FileNotFoundError:
    print("❌ Failed to load ABI: PBACSystem_abi.json not found.")
    exit()
except Exception as e:
    print(f"❌ Failed to load ABI: {e}")
    exit()

# Contract setup
contract_address = w3.to_checksum_address("0xfeae27388A65eE984F452f86efFEd42AaBD438FD")
contract = w3.eth.contract(address=contract_address, abi=contract_abi)
print("⚠️ Skipping contract verification for Besu compatibility")

# Accounts configuration
# Swapped patient and requester accounts as requested by the user
accounts = {
    'controller': {
        'address': '0xFE3B557E8Fb62b89F4916B721be55cEb828dBd73',
        'private_key': '0x8f2a55949038a9610f50fb23b5883af3b4ecb3c3bb792cbcefbd1542c692be63',
    },
    'patient': {
        'address': '0x627306090abaB3A6e1400e9345bC60c78a8BEf57',
        'private_key': '0xc87509a1c067bbde78beb793e6fa76530b6382a4c0241e5e4a9ec0a0f44dc0d3',
    },
    'requester': {
        'address': '0xf17f52151EbEF6C7334FAD080c5704D77216b732',
        'private_key': '0xae6ae8e5ccbfb04590405997ee2d52d2b330726137b875053c36d94e974d162f',
    },
    'delegate': {
        'address': '0x4fC7c39e6E49895137170675CF8a19D121540784',
        'private_key': '0x6a0a09e0a81418b7654c600f13f1c1d8c1e63a3d5f81c9a66d03f0b2404b8e2d',
    }
}

# Constants
POLICY_KIND = {'Emergency': 0, 'Normal': 1, 'Delegate': 2}
ACCESS = {'None': 0, 'Partial': 1, 'Full': 2}
STATUS_LABEL = {0: 'Pending', 1: 'Granted', 2: 'Denied'}
REASON_LABEL = {
    0: 'None', 1: 'AccessLevelTooHigh', 2: 'PurposeMismatch',
    3: 'PolicyDisabled', 4: 'NoConsent', 5: 'TimeExpired'
}

def send_tx(fn, sender_role, step_name, gas=300000):
    """Send transaction with proper error handling"""
    sender = accounts[sender_role]
    
    try:
        tx = fn.build_transaction({
            'chainId': 1337,
            'gas': gas,
            'gasPrice': w3.to_wei('1', 'gwei'),
            'nonce': w3.eth.get_transaction_count(sender['address']),
        })
        
        signed_tx = w3.eth.account.sign_transaction(tx, sender['private_key'])
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        
        if receipt.status == 1:
            print(f"✅ {step_name} successful (tx: {tx_hash.hex()})")
            return receipt
        else:
            print(f"❌ {step_name} failed: Transaction reverted.")
            return None
    except Exception as e:
        print(f"❌ {step_name} failed: {str(e)}")
        return None

def check_patient_exists(patient_addr):
    """Check if patient exists"""
    try:
        patient = contract.functions.patients(patient_addr).call()
        return patient[0]  # exists flag
    except Exception as e:
        print(f"❌ Error checking patient: {str(e)}")
        return False

def register_patient():
    """Register or update patient if not already registered"""
    patient_addr = accounts['patient']['address']
    print("\n1. Checking patient registration...")
    
    if check_patient_exists(patient_addr):
        print("⚠️ Patient already registered, re-registering to ensure correct delegate...")
    else:
        print("Registering new patient...")
    
    # ----------------------------------------------------
    # Step 1: Patient Registration Details
    # The patient is the address in accounts['patient']['address'].
    # The delegate is the address in accounts['delegate']['address'].
    # This transaction is sent by the controller account.
    # The function call is registerPatient(patientAddress, "John Doe", "diabetes", delegateAddress, "Med: X", "Age: 30")
    # ----------------------------------------------------
    receipt = send_tx(
        contract.functions.registerPatient(
            patient_addr,
            "John Doe",
            "diabetes",
            accounts['delegate']['address'],  # Correct delegate address
            "Med: X",
            "Age: 30"
        ),
        'controller',
        "Patient Registration"
    )
    return receipt and receipt.status == 1

def create_policy(kind, access, purpose, duration, consent, creator_role):
    """Create policy with given parameters"""
    print(f"\n2. Creating {kind} policy ({access} access)...")
    
    # ----------------------------------------------------
    # Step 2: Policy Creation Details
    # A new policy is created with the following parameters:
    # kind: 'Delegate' (2)
    # access: 'Full' (2) for the first test, 'Partial' (1) for the second
    # purpose: 'ProxyCare' for the first test, 'LabResults' for the second
    # duration: 172800 for the first test, 259200 for the second
    # consent: True for the first test, False for the second
    # This transaction is sent by the delegate account.
    # ----------------------------------------------------
    receipt = send_tx(
        contract.functions.createPolicy(
            POLICY_KIND[kind],
            ACCESS[access],
            purpose,
            duration,
            consent
        ),
        creator_role,
        "Policy Creation",
        gas=400000
    )
    return receipt and receipt.status == 1

def assign_policy(policy_id, assigner_role):
    """Assign policy"""
    print(f"\n3. Assigning policy {policy_id}...")
    
    # ----------------------------------------------------
    # Step 3: Policy Assignment Details
    # The policy with ID 'policy_id' is assigned.
    # This transaction is sent by the delegate account.
    # ----------------------------------------------------
    try:
        receipt = send_tx(
            contract.functions.assignPolicy(policy_id),
            assigner_role,
            "Policy Assignment"
        )
        return receipt and receipt.status == 1
    except Exception as e:
        print(f"❌ Policy assignment failed: {str(e)}")
        return False

def request_access(nonce_id, purpose, access_level):
    """Request access with specified purpose and access level"""
    print(f"\n4. Requesting access for '{purpose}' (nonce: {nonce_id})...")
    
    # ----------------------------------------------------
    # Step 4: Access Request Details
    # The requester is the address in accounts['requester']['address'].
    # The request is for the condition 'diabetes'.
    # The purpose is 'ProxyCare' or 'LabResults'.
    # The requested access level is 'Full' for both tests.
    # ----------------------------------------------------
    receipt = send_tx(
        contract.functions.requestAccess(
            "diabetes",
            purpose,
            ACCESS[access_level],
            nonce_id
        ),
        'requester',
        "Access Request"
    )
    return receipt and receipt.status == 1

def check_status(nonce_id):
    """Check access request status with proper permissions."""
    
    # ----------------------------------------------------
    # Step 5: Status Check Details
    # The status of the access request is checked based on the unique nonce_id.
    # This is a read-only call (no transaction).
    # It checks the status from the perspective of the requester account.
    # The output will show:
    # - The Status (e.g., Granted, Pending, Denied)
    # - The Reason (e.g., None, NoConsent)
    # - Whether Medical/Demographic Info is available
    # ----------------------------------------------------
    try:
        status_info = contract.functions.statusByRequester(nonce_id).call({
            'from': accounts['requester']['address']
        })
        
        print("\nAccess Status:")
        print(f"• Status: {STATUS_LABEL[status_info[0]]}")
        print(f"• Reason: {REASON_LABEL[status_info[1]]}")
        print(f"• Medical Info: {'Available' if status_info[2] else 'Restricted'}")
        print(f"• Demographic Info: {'Available' if status_info[3] else 'Restricted'}")
        return status_info
    except Exception as e:
        print(f"❌ Status check failed: {str(e)}")
        return None

def check_delegate_registration():
    """Check if delegate is properly registered"""
    print("\n🔍 Checking delegate registration...")
    try:
        patient_addr = accounts['patient']['address']
        patient = contract.functions.patients(patient_addr).call()
        
        if not patient[0]:  # exists flag
            print("❌ Patient does not exist")
            return False
        
        registered_delegate = patient[4]  # delegateAddress field
        expected_delegate = accounts['delegate']['address']
        
        print(f"Patient delegate: {registered_delegate}")
        print(f"Expected delegate: {expected_delegate}")
        
        if registered_delegate.lower() == expected_delegate.lower():
            print("✅ Delegate is properly registered")
            return True
        else:
            print("❌ Delegate address mismatch")
            return False
            
    except Exception as e:
        print(f"❌ Error checking delegate registration: {str(e)}")
        return False

def run_test_scenario(scenario, test_num):
    """Runs a single test scenario based on the provided table."""
    kind, policy_access, policy_purpose, consent, requester_access, request_purpose, duration, expected_status, expected_reason, expected_medical, expected_demo = scenario
    
    print(f"\n{'='*50}")
    print(f"🚀 Running Test #{test_num}: {kind} {policy_purpose} ({policy_access} policy)")
    print(f"Expected: {expected_status} ({expected_reason})")
    print(f"{'='*50}")
    
    # --- Step 1: Register Patient ---
    print("\nExecuting Step 1: Patient Registration...")
    if not register_patient():
        print("❌ Cannot proceed - patient registration failed")
        return False
    
    # Verify delegate registration
    if not check_delegate_registration():
        print("❌ Delegate registration check failed")
        return False
    
    # Delegate policies must be created and assigned by the DELEGATE account.
    creator_role = 'delegate'
    assigner_role = 'delegate'
    
    # --- Step 2: Create Policy ---
    print("\nExecuting Step 2: Policy Creation...")
    if not create_policy(kind, policy_access, policy_purpose, duration, consent, creator_role):
        print("❌ Policy creation failed")
        return False
    
    policy_id = contract.functions.policyCount().call()
    
    # --- Step 3: Assign Policy ---
    print(f"\nExecuting Step 3: Assigning Policy {policy_id}...")
    if not assign_policy(policy_id, assigner_role):
        print("❌ Policy assignment failed")
        return False
    
    nonce_id = int(time.time()) + random.randint(1, 10000)
    
    # --- Step 4: Request Access ---
    print("\nExecuting Step 4: Access Request...")
    if not request_access(nonce_id, request_purpose, requester_access):
        print("❌ Access request failed")
        return False
    
    print("\n⏳ Waiting for transactions to finalize...")
    time.sleep(3)
    
    # --- Step 5: Check Status ---
    print("\nExecuting Step 5: Checking Request Status...")
    status_info = check_status(nonce_id)
    if not status_info:
        return False
    
    current_status_label = STATUS_LABEL[status_info[0]]
    current_reason_label = REASON_LABEL[status_info[1]]
    
    status_match = current_status_label == expected_status
    reason_match = current_reason_label == expected_reason
    medical_match = (status_info[2] and expected_medical == "Available") or (not status_info[2] and expected_medical == "Restricted")
    demo_match = (status_info[3] and expected_demo == "Available") or (not status_info[3] and expected_demo == "Restricted")
    
    if status_match and reason_match and medical_match and demo_match:
        print(f"\n✅ Test #{test_num} PASSED - Result matches expected.")
        return True
    else:
        print(f"\n❌ Test #{test_num} FAILED - Mismatched outcomes.")
        print(f"  - Status: Expected '{expected_status}', Got '{current_status_label}'")
        print(f"  - Reason: Expected '{expected_reason}', Got '{current_reason_label}'")
        print(f"  - Medical: Expected '{expected_medical}', Got '{'Available' if status_info[2] else 'Restricted'}'")
        print(f"  - Demo: Expected '{expected_demo}', Got '{'Available' if status_info[3] else 'Restricted'}'")
        return False

def main():
    test_scenarios = [
        # kind, policy_access, policy_purpose, consent, requester_access, request_purpose, duration, expected_status, expected_reason, expected_medical, expected_demo
        ("Delegate", "Full", "ProxyCare", True, "Full", "ProxyCare", 172800, "Granted", "None", "Available", "Available"),
        ("Delegate", "Partial", "LabResults", False, "Full", "LabResults", 259200, "Pending", "NoConsent", "Restricted", "Restricted"),
    ]
    
    print("Starting PBAC Test Suite (2 Delegate Scenarios)\n")
    
    granted_count = 0
    denied_count = 0
    pending_count = 0
    
    results = []
    for i, scenario in enumerate(test_scenarios, 1):
        test_passed = run_test_scenario(scenario, i)
        results.append(test_passed)
        if test_passed:
            if scenario[7] == 'Granted':
                granted_count += 1
            elif scenario[7] == 'Denied':
                denied_count += 1
            elif scenario[7] == 'Pending':
                pending_count += 1
        time.sleep(2)
    
    print("\nTest Summary:")
    print(f"Tests Passed: {sum(results)}/{len(test_scenarios)}")
    print(f"Granted: {granted_count}, Denied: {denied_count}, Pending: {pending_count}")

if __name__ == "__main__":
    main()
