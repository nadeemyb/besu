from web3 import Web3
from web3.exceptions import ContractLogicError
import json
import time
import random

# Connect to Ethereum node with POA middleware
w3 = Web3(Web3.HTTPProvider("http://localhost:8545"))

# Add POA middleware for Besu compatibility
w3.middleware_onion.inject(lambda middleware: middleware(w3), 'poa')

if not w3.is_connected():
    print("❌ Failed to connect to Ethereum node")
    exit()

# Load contract ABI
try:
    with open("PBACSystem_abi.json") as f:
        contract_abi = json.load(f)
except Exception as e:
    print(f"❌ Failed to load ABI: {e}")
    exit()

# Initialize contract
contract_address = "0x1349F3e1B8D71eFfb47B840594Ff27dA7E603d17"
contract = w3.eth.contract(address=contract_address, abi=contract_abi)

# Verify contract
if w3.eth.get_code(contract_address) == b'':
    print("❌ Contract not deployed at", contract_address)
    exit()
else:
    print("✅ Contract verified at", contract_address)

# Test accounts
accounts = {
    'controller': {
        'address': '0xed9d02e382b34818e88B88a309c7fe71E65f419d',
        'private_key': '0xe6181caaffff94a09d7e332fc8da9884d99902c7874eb74354bdcadf411929f1',
    },
    'patient': {
        'address': '0xf48dE4A0C2939E62891F3C6ACA68982975477E45',
        'private_key': '0x7f012b2a11fc651c9a73ac13f0a298d89186c23c2c9a0e83206ad6e274ba3fc7',
    },
    'requester': {
        'address': '0xce412f988377e31f4d0ff12d74df73b51c42d0ca',
        'private_key': '0xf23f92ed543046498d7616807b18a8f304855cb644df25bc7d0b0b37d8a66019',
    }
}

# Constants
POLICY_KIND = {'Emergency': 0, 'Normal': 1, 'Delegate': 2}
ACCESS = {'None': 0, 'Partial': 1, 'Full': 2}
STATUS_LABEL = {0: 'Pending', 1: 'Granted', 2: 'Denied'}
REASON_LABEL = {
    0: 'None', 1: 'AccessLevelTooHigh', 2: 'PurposeMismatch',
    3: 'PolicyDisabled', 4: 'NoConsent'
}

def get_last_policy_id():
    return contract.functions.policyCount().call()

def print_transaction_details(receipt, step_name):
    """Print detailed transaction information"""
    print(f"\n📝 {step_name} Transaction Details:")
    print(f"• Transaction Hash: {receipt.transactionHash.hex()}")
    print(f"• Block Number: {receipt.blockNumber}")
    print(f"• Gas Used: {receipt.gasUsed}")
    print(f"• From: {receipt['from']}")
    print(f"• To: {receipt['to']}")
    print(f"• Status: {'Success' if receipt.status == 1 else 'Failed'}")

def send_tx(fn, sender_role, step_name):
    """Send transaction with proper error handling"""
    sender = accounts[sender_role]
    
    try:
        # Build transaction
        tx = {
            'chainId': 1337,
            'gas': 500000,
            'gasPrice': w3.to_wei('20', 'gwei'),
            'nonce': w3.eth.get_transaction_count(sender['address']),
            'data': fn._encode_transaction_data()
        }
        
        # Sign and send
        signed_tx = w3.eth.account.sign_transaction(tx, sender['private_key'])
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        
        print(f"✅ {step_name} mined in block {receipt.blockNumber}")
        print_transaction_details(receipt, step_name)
        return receipt
    except Exception as e:
        print(f"❌ {step_name} failed: {str(e)}")
        return None

def register_patient_explicit(patient_addr, name, diagnosis, delegate_addr, medical_info, demo_info):
    print("\n1. Registering patient (explicit params)...")
    receipt = send_tx(
        contract.functions.registerPatient(
            patient_addr, name, diagnosis, delegate_addr, medical_info, demo_info
        ),
        'controller',
        "Patient Registration"
    )
    
    if not receipt or receipt.status != 1:
        return False
    
    # Verify registration
    try:
        patient = contract.functions.patients(patient_addr).call()
        return patient[0]  # exists flag
    except Exception as e:
        print(f"❌ Error verifying registration: {str(e)}")
        return False

def create_policy_explicit(kind_label, access_label, purpose, duration_sec, initial_consent):
    print("\n2. Creating policy (explicit params)...")
    receipt = send_tx(
        contract.functions.createPolicy(
            POLICY_KIND[kind_label],
            ACCESS[access_label],
            purpose,
            duration_sec,
            initial_consent
        ),
        'patient',
        "Policy Creation"
    )
    
    if not receipt or receipt.status != 1:
        return None
        
    policy_id = get_last_policy_id()
    print(f"→ Created policyId = {policy_id}")
    return policy_id

def assign_policy_explicit(policy_id):
    print(f"\n3. Assigning policy {policy_id}...")
    receipt = send_tx(
        contract.functions.assignPolicy(policy_id),
        'patient',
        "Policy Assignment"
    )
    return receipt and receipt.status == 1

def request_access_explicit(diagnosis, purpose, access_label, nonce_id):
    print(f"\n4. Requesting access (nonce {nonce_id})...")
    receipt = send_tx(
        contract.functions.requestAccess(
            diagnosis,
            purpose,
            ACCESS[access_label],
            nonce_id
        ),
        'requester',
        "Access Request"
    )
    return receipt and receipt.status == 1

def status_by_requester(nonce):
    """Check access request status"""
    try:
        status = contract.functions.statusByRequester(nonce).call()
        return {
            'status': status[0],
            'reason': status[1],
            'medicalInfo': status[2],
            'demographicInfo': status[3],
            'consentType': status[4],
            'policyId': status[5],
            'policyPurpose': status[6]
        }
    except Exception as e:
        print(f"❌ Status check failed: {str(e)}")
        return None

def format_status(status):
    """Format status for display"""
    if not status:
        return
        
    print("\n📋 Access Request Status:")
    print(f"• Status: {STATUS_LABEL[status['status']]}")
    print(f"• Reason: {REASON_LABEL[status['reason']]}")
    print(f"• Medical Info: {status['medicalInfo']}")
    print(f"• Demographic Info: {status['demographicInfo']}")
    print(f"• Consent Type: {status['consentType']}")
    print(f"• Policy ID: {status['policyId']}")
    print(f"• Policy Purpose: {status['policyPurpose']}")
    
    return status['status'] == 1  # Return True if granted

def main_explicit():
    print("🚀 Starting PBAC Workflow (explicit params)")

    # 1) Register patient
    if not register_patient_explicit(
        accounts['patient']['address'],
        "John",
        "diabetes",
        accounts['controller']['address'],
        "Med: X",
        "Age: 30"
    ):
        print("❌ Stopping: Patient registration failed")
        return

    # 2) Create policy
    policy_id = create_policy_explicit(
        "Normal",
        "Partial",
        "Treatment",
        2592000,  # 30 days
        True
    )
    if not policy_id:
        print("❌ Stopping: Policy creation failed")
        return

    # 3) Assign policy
    if not assign_policy_explicit(policy_id):
        print("❌ Stopping: Policy assignment failed")
        return

    # 4) Request access
    nonce_id = int(time.time()) + random.randint(1, 10000)
    if not request_access_explicit("diabetes", "Treatment", "Partial", nonce_id):
        print("❌ Stopping: Access request failed")
        return

    # 5) Check status
    print("\n⏳ Waiting for transactions to finalize...")
    time.sleep(3)
    
    print("\n🔍 Checking access status...")
    result = status_by_requester(nonce_id)
    if result:
        access_granted = format_status(result)
        if access_granted:
            print("\n✅ Access granted!")
        else:
            print("\n⚠️ Access not granted")
    else:
        print("❌ Failed to check access status")

if __name__ == "__main__":
    main_explicit()