// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

contract PBACContract {
    address public controller;
    uint256 public lastPolicyId;

    // Enums - UPDATED
    enum PolicyKind { Emergency, Normal, Delegate }
    enum AccessLevel { None, Partial, Full }
    enum ConsentStatus { Pending, Granted, Denied, PartialGranted } // ADDED PartialGranted
    enum DenialReason {
        None, PurposeMismatch, AccessLevelTooHigh, ConsentNotGranted,
        PolicyInactive, PolicyExpired, NotDelegate, InvalidPolicyType,
        RequestAlreadyProcessed, PatientDoesNotExist, InvalidRequest,
        NeedApproval // ADDED NeedApproval
    }

    // Structs
    struct Patient {
        address patientAddress;
        string name;
        string diagnosis;
        uint256 activePolicyId;
        address delegateAddress;
        bool exists;
        string medicalInfo;
        string demographicInfo;
    }

    struct Policy {
        uint256 policyId;
        PolicyKind kind;
        AccessLevel access;
        bool isActive;
        bool isEnabled;
        string purpose;
        address creator;
        uint256 validFrom;
        uint256 validUntil;
        bool isConsentGranted;
    }

    struct AccessRequest {
        address requesterAddress;
        address patientAddress;
        string purpose;
        AccessLevel access;
        ConsentStatus status;
        DenialReason denialReason;
        uint256 timestamp;
        uint256 policyIdAtRequest;
    }

    // Mappings
    mapping(address => Patient) public patients;
    mapping(uint256 => Policy) public policies;
    mapping(uint256 => AccessRequest) public accessRequests;
    mapping(string => address) private diagnosisToPatient;
    mapping(address => address) private delegateToPatient;

    // Events
    event PatientRegistered(address indexed patient);
    event PolicyCreated(uint256 indexed policyId, PolicyKind kind);
    event PolicyAssigned(address indexed patient, uint256 policyId);
    event PolicyEnabled(uint256 indexed policyId);
    event PolicyDisabled(uint256 indexed policyId);
    event AccessRequested(uint256 indexed nonceID);
    event AccessGranted(uint256 indexed nonceID);
    event AccessDenied(uint256 indexed nonceID, DenialReason reason);
    event PendingRequest(uint256 indexed nonceID, address indexed patient);
    event ConsentUpdated(uint256 indexed policyId, bool newConsentStatus);
    event PatientNotified(address indexed patient, string message);
    event DebugPolicyPurpose(uint256 policyId, string purpose);
    event PartialAccessGranted(uint256 indexed nonceID); // ADDED new event

    modifier onlyController() {
        require(msg.sender == controller, "Unauthorized: Controller only");
        _;
    }

    constructor() public {
        controller = msg.sender;
    }

    // ========== PATIENT MANAGEMENT ========== //

    function registerPatient(
        address patientAddress,
        string memory name,
        string memory diagnosis,
        address delegateAddress,
        string memory medicalInfo,
        string memory demographicInfo
    ) external onlyController {
        require(!patients[patientAddress].exists, "Patient already exists");
        require(bytes(diagnosis).length > 0, "Diagnosis cannot be empty");
        
        patients[patientAddress] = Patient({
            patientAddress: patientAddress,
            name: name,
            diagnosis: diagnosis,
            activePolicyId: 0,
            delegateAddress: delegateAddress,
            exists: true,
            medicalInfo: medicalInfo,
            demographicInfo: demographicInfo
        });
        
        diagnosisToPatient[diagnosis] = patientAddress;
        if (delegateAddress != address(0)) {
            delegateToPatient[delegateAddress] = patientAddress;
        }
        emit PatientRegistered(patientAddress);
    }

    // ========== POLICY MANAGEMENT ========== //

    function createPolicy(
        PolicyKind kind,
        AccessLevel access,
        string memory purpose,
        uint256 duration,
        bool initialConsent
    ) external returns (uint256) {
        require(bytes(purpose).length > 0, "Purpose cannot be empty");
        require(duration > 0, "Duration must be positive");
        
        if (kind == PolicyKind.Delegate) {
            require(delegateToPatient[msg.sender] != address(0), "Not a registered delegate");
        }

        uint256 policyId = ++lastPolicyId;
        policies[policyId] = Policy({
            policyId: policyId,
            kind: kind,
            access: access,
            isActive: true,
            isEnabled: true,
            purpose: purpose,
            creator: msg.sender,
            validFrom: block.timestamp,
            validUntil: block.timestamp + duration,
            isConsentGranted: initialConsent
        });

        emit DebugPolicyPurpose(policyId, purpose);
        emit PolicyCreated(policyId, kind);
        return policyId;
    }

    function assignPolicy(uint256 policyId) external {
        Policy storage policy = policies[policyId];
        require(policy.policyId != 0, "Policy does not exist");
        require(policy.isEnabled, "Policy is disabled");
        
        address patientAddress;
        
        if (policy.kind == PolicyKind.Delegate) {
            patientAddress = delegateToPatient[msg.sender];
            require(patientAddress != address(0), "Not a registered delegate");
            require(msg.sender == policy.creator, "Only policy creator can assign");
        } 
        else if (policy.kind == PolicyKind.Normal) {
            patientAddress = msg.sender;
            require(patientAddress == policy.creator, "Only patient can assign normal policy");
        }
        else { // Emergency
            require(msg.sender == controller, "Only controller can assign emergency policies");
            patientAddress = msg.sender;
        }

        Patient storage patient = patients[patientAddress];
        require(patient.exists, "Patient does not exist");
        
        patient.activePolicyId = policyId;
        emit PolicyAssigned(patientAddress, policyId);
    }

    function enablePolicy(uint256 policyId) external {
        Policy storage policy = policies[policyId];
        require(policy.policyId != 0, "Policy does not exist");
        require(
            msg.sender == policy.creator || 
            (policy.kind == PolicyKind.Delegate && msg.sender == patients[policy.creator].delegateAddress),
            "Unauthorized"
        );
        policy.isEnabled = true;
        emit PolicyEnabled(policyId);
    }

    function disablePolicy(uint256 policyId) external {
        Policy storage policy = policies[policyId];
        require(policy.policyId != 0, "Policy does not exist");
        require(
            msg.sender == policy.creator || 
            (policy.kind == PolicyKind.Delegate && msg.sender == patients[policy.creator].delegateAddress),
            "Unauthorized"
        );
        policy.isEnabled = false;
        emit PolicyDisabled(policyId);
    }

    function updateConsent(uint256 policyId, bool newConsentStatus) external {
        Policy storage policy = policies[policyId];
        require(policy.policyId != 0, "Policy does not exist");
        
        if (policy.kind == PolicyKind.Delegate) {
            require(msg.sender == patients[policy.creator].delegateAddress, "Delegate only");
        } else {
            require(msg.sender == policy.creator, "Policy owner only");
        }
        
        policy.isConsentGranted = newConsentStatus;
        
        if (newConsentStatus) {
            _processPendingRequests(policyId);
        }
        
        emit ConsentUpdated(policyId, newConsentStatus);
    }

    // ========== ACCESS CONTROL ========== //

    function requestAccess(
        string memory diagnosis,
        string memory purpose,
        AccessLevel accessLevel,
        uint256 nonceID
    ) external {
        require(bytes(diagnosis).length > 0, "Diagnosis cannot be empty");
        require(bytes(purpose).length > 0, "Purpose cannot be empty");
        require(accessRequests[nonceID].timestamp == 0, "NonceID already used");
        
        address patientAddress = diagnosisToPatient[diagnosis];
        require(patients[patientAddress].exists, "Patient does not exist");
        
        Patient storage patient = patients[patientAddress];
        require(patient.activePolicyId != 0, "No active policy");
        
        Policy storage policy = policies[patient.activePolicyId];
        require(policy.isEnabled, "Assigned policy is disabled");

        AccessRequest storage request = accessRequests[nonceID] = AccessRequest({
            requesterAddress: msg.sender,
            patientAddress: patientAddress,
            purpose: purpose,
            access: accessLevel,
            status: ConsentStatus.Pending,
            denialReason: DenialReason.None,
            timestamp: block.timestamp,
            policyIdAtRequest: patient.activePolicyId
        });

        DenialReason complianceCheck = _checkCompliance(request, policy);
        
        // UPDATED LOGIC TO MATCH TEST CASES
        if (complianceCheck != DenialReason.None) {
    // Test Case 3: Compliance issues -> Immediate Denial
    request.status = ConsentStatus.Denied;
    request.denialReason = complianceCheck;
    emit AccessDenied(nonceID, complianceCheck);
} else if (!policy.isConsentGranted) {
    // Test Case 4: No consent but otherwise compliant -> Pending with NeedApproval
    request.status = ConsentStatus.Pending;
    request.denialReason = DenialReason.NeedApproval;
    emit PendingRequest(nonceID, patientAddress);
} else if (policy.access == AccessLevel.Partial) {
    // Test Case 2: Has consent + Partial policy -> Partial Granted
    request.status = ConsentStatus.PartialGranted;
    emit PartialAccessGranted(nonceID);
} else {
    // Test Case 1: Perfect match -> Immediate Grant
    request.status = ConsentStatus.Granted;
    emit AccessGranted(nonceID);
}
        
        emit AccessRequested(nonceID);
    }

    function processRequest(uint256 nonceID, bool approve) external {
        AccessRequest storage request = accessRequests[nonceID];
        require(request.timestamp != 0, "Request does not exist");
        
        Policy storage policy = policies[request.policyIdAtRequest];
        require(policy.policyId != 0, "Policy does not exist");

        if (policy.kind == PolicyKind.Delegate) {
            require(msg.sender == patients[request.patientAddress].delegateAddress, "Delegate only");
        } else {
            require(msg.sender == controller, "Controller only");
        }

        DenialReason denialReason = approve ? 
            _checkCompliance(request, policy) : 
            DenialReason.ConsentNotGranted;
        
        if (denialReason == DenialReason.None) {
            request.status = ConsentStatus.Granted;
            emit AccessGranted(nonceID);
        } else {
            request.status = ConsentStatus.Denied;
            request.denialReason = denialReason;
            emit AccessDenied(nonceID, denialReason);
        }
    }

    // ========== VIEW FUNCTIONS ========== //

    function statusByRequester(uint256 nonceID) external view returns (
        ConsentStatus status,
        DenialReason reason,
        string memory medicalInfo,
        string memory demographicInfo,
        string memory consentType,
        uint256 policyId,
        string memory policyPurpose
    ) {
        AccessRequest storage request = accessRequests[nonceID];
        require(request.timestamp != 0, "Request does not exist");
        require(request.requesterAddress == msg.sender, "Unauthorized");
        
        Policy storage policy = policies[request.policyIdAtRequest];
        
        string memory kindStr;
        if (policy.kind == PolicyKind.Normal) kindStr = "Normal";
        else if (policy.kind == PolicyKind.Delegate) kindStr = "Delegate";
        else kindStr = "Emergency";
        
        string memory accessStr;
        if (policy.access == AccessLevel.Full) accessStr = "Full";
        else accessStr = "Partial";
        
        string memory consentTypeStr = string(abi.encodePacked(kindStr, "-", accessStr));
        
        // UPDATED to handle PartialGranted status
        if (request.status == ConsentStatus.Granted || request.status == ConsentStatus.PartialGranted) {
            string memory medInfo = (policy.access >= AccessLevel.Partial) ? 
                patients[request.patientAddress].medicalInfo : "";
            
            string memory demoInfo = (request.status == ConsentStatus.Granted && policy.access == AccessLevel.Full) ? 
                patients[request.patientAddress].demographicInfo : "";
            
            return (
                request.status,
                request.denialReason,
                medInfo,
                demoInfo,
                consentTypeStr,
                request.policyIdAtRequest,
                policy.purpose
            );
        } else {
            return (
                request.status,
                request.denialReason,
                "",
                "",
                consentTypeStr,
                request.policyIdAtRequest,
                policy.purpose
            );
        }
    }

    function policyCount() external view returns (uint256) {
        return lastPolicyId;
    }

    function getPatientByDiagnosis(string memory diagnosis) external view returns (address) {
        return diagnosisToPatient[diagnosis];
    }

    function notifyPatient(address patient, string memory message) external onlyController {
        require(patients[patient].exists, "Patient does not exist");
        emit PatientNotified(patient, message);
    }

    // ========== INTERNAL FUNCTIONS ========== //

    function _processPendingRequests(uint256 policyId) internal {
        // Implementation for processing pending requests
        // Could be enhanced based on specific requirements
    }

    function debugPolicy(uint256 policyId) external view returns (
        bool exists,
        bool isEnabled,
        PolicyKind kind,
        address creator,
        address patientDelegate
    ) {
        Policy memory p = policies[policyId];
        return (
            p.policyId != 0,
            p.isEnabled,
            p.kind,
            p.creator,
            patients[p.creator].delegateAddress
        );
    }

    function debugCanAssign(uint256 policyId, address caller) external view returns (
        bool canAssign,
        string memory reason
    ) {
        Policy storage p = policies[policyId];
        if (p.policyId == 0) return (false, "Policy doesn't exist");
        if (!p.isEnabled) return (false, "Policy disabled");
        
        if (p.kind == PolicyKind.Normal) {
            return (caller == p.creator, "Caller must be patient");
        }
        else if (p.kind == PolicyKind.Delegate) {
            return (caller == patients[p.creator].delegateAddress, "Caller must be delegate");
        }
        else {
            return (caller == controller, "Caller must be controller");
        }
    }

    function _checkCompliance(
        AccessRequest memory request,
        Policy memory policy
    ) internal view returns (DenialReason) {
        if (!policy.isActive) return DenialReason.PolicyInactive;
        if (block.timestamp > policy.validUntil) return DenialReason.PolicyExpired;
        if (request.access > policy.access) return DenialReason.AccessLevelTooHigh;
        if (keccak256(abi.encodePacked(request.purpose)) != keccak256(abi.encodePacked(policy.purpose))) {
            return DenialReason.PurposeMismatch;
        }
        return DenialReason.None;
    }
}